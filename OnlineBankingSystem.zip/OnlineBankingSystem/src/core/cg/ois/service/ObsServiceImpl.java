package core.cg.ois.service;

import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.dao.IObsDao;
import core.cg.ois.dao.ObsDaoImpl;
import core.cg.ois.exception.LoginException;

public class ObsServiceImpl implements IObsService {
	private IObsDao dao = null;




	public ObsServiceImpl() {
		dao = new ObsDaoImpl();
		// TODO Auto-generated constructor stub
	}




	@Override
	public int loginProcess(UserTable user) throws LoginException {
		return dao.loginProcess(user);
		// TODO Auto-generated method stub

	}




	@Override
	public void update(int lock) {
		dao.update(lock);
		
	}




	@Override
	public AccountMaster getAccount(int accountId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.getAccount(accountId);
	}




	@Override
	public String SecurityQues(int userId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.SecurityQues(userId);
	}




	@Override
	public int confirmQues(String ques, String transPass) throws LoginException {
		// TODO Auto-generated method stub
		return dao.confirmQues(ques, transPass);
	}




	@Override
	public void passwordChange(int userId, String pas) throws LoginException {
		dao.passwordChange(userId, pas);
		
	}




	@Override
	public List<Transaction> getAllTransaction(int accId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.getAllTransaction(accId);
	}




	@Override
	public Customer getPersonalDetails(int accId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.getPersonalDetails(accId);
	}




	@Override
	public void updateCustomer(Customer cust) throws LoginException {
		 dao.updateCustomer(cust);
		
	}




	@Override
	public int requestCheckBook(int accId, String desc) throws LoginException {
		// TODO Auto-generated method stub
		return dao.requestCheckBook(accId, desc);
	}




	@Override
	public List<ServiceTracker> trackRequest(int accId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.trackRequest(accId);
	}




	@Override
	public Customer getCustomerName(int accounId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.getCustomerName(accounId);
	}







	@Override
	public List<PayeeTable> getPayeeList(int accId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.getPayeeList(accId);
	}




	@Override
	public void addPayee(PayeeTable payee) throws LoginException {
		dao.addPayee(payee);
		
	}




	@Override
	public List<AccountMaster> checkPayeeId(int payeeId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.checkPayeeId(payeeId);
	}




	@Override
	public int ownFundTransfer(int accountPayer, int accountPayee, double amount) throws LoginException {
		return dao.ownFundTransfer(accountPayer, accountPayee, amount);
		
	}




	@Override
	public boolean register(UserTable user) throws LoginException {
		// TODO Auto-generated method stub
		return dao.register(user);
	}
	
	




	

}
